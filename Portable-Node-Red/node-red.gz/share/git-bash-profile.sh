[ -e /etc/profile ] && source /etc/profile
[ -e "$NODE_PATH/../lib/node_modules/npm/lib/utils/completion.sh" ] && source "$NODE_PATH/../lib/node_modules/npm/lib/utils/completion.sh"
echo Started Node Environment
