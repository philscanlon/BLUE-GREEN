#!/bin/sh
docker build -t easuncion/solace-rest-get .
